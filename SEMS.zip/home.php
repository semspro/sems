<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div>
	<div class="col-sm-3 module" align="center">
    <h1>SETTINGS<br /><span style="font-size:100px;" class="glyphicon glyphicon-cog" aria-hidden="true"></span></h1>
    </div>
    <div class="col-sm-5 module" align="center">
    <h1>PURCHASE<br /><span style="font-size:100px;" class="glyphicon glyphicon-remove" aria-hidden="true"></span></h1>
    </div>
    <div class="col-sm-3 module" align="center">
    <h1>MANTENANCE<br /><span style="font-size:100px;" class="glyphicon glyphicon-home" aria-hidden="true"></span></h1>
    </div>
    <div class="col-sm-5 module" align="center">
    <h1>REPAIR<br /><span style="font-size:100px;" class="glyphicon glyphicon-trash" aria-hidden="true"></span></h1>
    </div>
    <div class="col-sm-6 module" align="center">
    <h1>DISPOSAL<br /><span style="font-size:100px;" class="glyphicon glyphicon-search" aria-hidden="true"></span></h1>
    </div>

</div>
</body>
</html>