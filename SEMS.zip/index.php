<?php
include("includes/functions.php");
$pg="";
if(isset($_GET['pg'])){
$pg = urldecode($_GET['pg']);
//$pg = encryptor('decrypt', $pg);
}else{
$pg="home";
}

 ?>


<!DOCTYPE html>
<html lang="en">
  

  
        <!-- /top navigation -->
		<?php
			tops();
			sidebar();
			
		
		 ?>
        <!-- page content -->
        <div class="right_col" role="main">
        
        <?php 
			include($pg.'.php');
		?>
        
        </div>
               
        <!-- /page content -->

        <!-- footer content -->
        <?php
		
			bottoms();
		 ?>
        
	
  </body>
</html>
